#!/usr/bin/env node
require('./server.js').run(process.argv);