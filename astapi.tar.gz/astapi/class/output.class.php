<?php

class OutPut {

    function error($message){
        echo json_encode(array("status"=>false,"message"=>$message),JSON_UNESCAPED_UNICODE);
	echo $srcExten;
	echo $dstPhone;
	echo $context;
    }

    function success($message){
        echo json_encode(array("status"=>true,"message"=>$message),JSON_UNESCAPED_UNICODE);
    }
}
