<?php
/**
 * asterisk manager 配置
 */
header("Content-type: text/html; charset=utf-8");
date_default_timezone_set("PRC");

$config['ami'] = array(
    "server" => "172.18.18.31",
    "username" => "cron",
    "secret" => "1234",
    "port" => 5038,
    "timeout" => 3
);

$config['context'] = "from-exten-sip";
