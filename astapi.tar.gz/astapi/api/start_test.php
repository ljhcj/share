<?php
header("Access-Control-Allow-Origin:*");
header('Access-Control-Allow-Methods:POST');
header('Access-Control-Allow-Headers:x-requested-with, content-type');
include "../config/config.php";
include "../class/output.class.php";
include "../libs/phpagi/phpagi-asmanager.php";

/**
 * 参数检查
 * API调用：
 *      http://api.astcalls.com/api/startcall.php?srcExten=000&dstPhone=123456789
 * srcExten 分机号码
 * dstPhone 目标号码
 * api.astcalls.com  IP地址也可以，API服务器的地址
 */
$srcExtenTmp = isset($_REQUEST['srcExten']) && !empty($_REQUEST['srcExten']) ? $_REQUEST['srcExten'] : "";
$dstPhoneTmp = isset($_REQUEST['dstPhone']) && !empty($_REQUEST['dstPhone']) ? $_REQUEST['dstPhone'] : "";

$srcExten = trim($srcExtenTmp);
$dstPhone = trim($dstPhoneTmp);
$context = $config['context'];

$output = new OutPut();

if ($srcExten == "" || $dstPhone == "") {
    $output->error("参数异常：参数不能为空！");
    exit;
}

if (!is_numeric($srcExten) || !is_numeric($dstPhone)) {
    $output->error("参数异常：参数不能包含非数字字符！");
    exit;
}
echo $srcExten;
echo $dstPhone;
echo $context;
