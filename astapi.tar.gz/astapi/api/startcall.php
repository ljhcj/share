<?php
header("Access-Control-Allow-Origin:*");
header('Access-Control-Allow-Methods:POST');
header('Access-Control-Allow-Headers:x-requested-with, content-type');
include "../config/config.php";
include "../class/output.class.php";
include "../libs/phpagi/phpagi-asmanager.php";

/**
 * 参数检查
 * API调用：
 *      http://api.astcalls.com/api/startcall.php?srcExten=000&dstPhone=123456789
 * srcExten 分机号码
 * dstPhone 目标号码
 * api.astcalls.com  IP地址也可以，API服务器的地址
 */
$srcExtenTmp = isset($_REQUEST['srcExten']) && !empty($_REQUEST['srcExten']) ? $_REQUEST['srcExten'] : "";
$dstPhoneTmp = isset($_REQUEST['dstPhone']) && !empty($_REQUEST['dstPhone']) ? $_REQUEST['dstPhone'] : "";
$agentidTmp = isset($_REQUEST['agentid']) && !empty($_REQUEST['agentid']) ? $_REQUEST['agentid'] : "";
$dataidTmp = isset($_REQUEST['dataid']) && !empty($_REQUEST['dataid']) ? $_REQUEST['dataid'] : "";

$srcExten = trim($srcExtenTmp);
$dstPhone = trim($dstPhoneTmp);
$context = $config['context'];
$agentid = trim($agentidTmp);
$dataid = trim($dataidTmp);
$output = new OutPut();

if ($srcExten == "" || $dstPhone == "" || $agentid == "" || $dataid == "" ) {
    $output->error("参数异常：参数不能为空！");
    exit;
}

if (!is_numeric($srcExten) || !is_numeric($dstPhone) || !is_numeric($agentid) || !is_numeric($dataid)) {
    $output->error("参数异常：参数不能包含非数字字符！");
    exit;
}

try {
    $amiConfig = $config['ami'];
    $astm = new AGI_AsteriskManager(null, $amiConfig);
    $result = $astm->connect();
    if (!$result) {
        $output->error("无法连接asterisk！" . $amiConfig['server']);
        exit;
    }
} catch (Exception $e) {
    $output->error("无法连接asterisk！" . $amiConfig['server']);
    exit;
}

/*
string $channel: Channel name to call
string $exten: Extension to use (requires 'Context' and 'Priority')
string $context: Context to use (requires 'Exten' and 'Priority')
string $priority: Priority to use (requires 'Exten' and 'Context')
string $application: Application to use
string $data: Data to use (requires 'Application')
integer $timeout: How long to wait for call to be answered (in ms)
string $callerid: Caller ID to be set on the outgoing channel
string $variable: Channel variable to set (VAR1=value1|VAR2=value2)
string $account: Account code
boolean $async: true fast origination
string $actionid: message matching variable
 */
$channel = "SIP/".$srcExten;
$exten = $dstPhone;
$priority = 1;
$timeout = 30;
$async = false;

$result = $astm->Originate($channel, $exten, $context, 1, null, null, $timeoout, $srcExten, null, null, $srcExten, $async);
if($result['Response'] == "Error"){
    $output->error($result['Message']);
}else{
    $output->success($result['Message']);

/*$output->success($result);
*/
}
sleep(5); 
$conn = new mysqli("172.18.18.31","root","qiji.com","freeiris2");
//检测连接
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}  
$sql = "INSERT INTO tm_call (src, dst, agentid, dataid, userfield,voiceid)
VALUES ('$srcExten', '$dstPhone', '$agentid', '$dataid',(select frist_cdruniqueid from callsession where  callernumber='$srcExten' and extension='$dstPhone' ORDER BY id DESC limit 1),(select id from callsession where  callernumber='$srcExten' and extension='$dstPhone' ORDER BY id DESC limit 1))";

if ($conn->query($sql) === TRUE) {
    echo "新记录插入成功";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
 
$conn->close();

